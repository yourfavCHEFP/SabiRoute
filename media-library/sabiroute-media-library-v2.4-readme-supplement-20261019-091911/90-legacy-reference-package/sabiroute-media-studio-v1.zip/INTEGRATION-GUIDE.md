# Integration guide (review-first)

Nothing in this package is integrated into the SabiRoute product or repository.

| Asset | Suggested destination | Before use |
|---|---|---|
| `01-logo-and-identity/logo-lockup-concept-01.jpg` and other logo concepts | Design reference for canonical logo | Select a concept; reconstruct clean SVG and export light/dark/monochrome variants |
| `02-website/abstract-routing-network.jpg` | Website feature background | Check contrast, crop safety, and file size; do not use as an interface screenshot |
| `02-website/health-and-resilience-feature.jpg` | Website feature illustration | Review labels and semantics |
| `02-website/how-sabiroute-works.jpg` | Website “How it works” section | Rewrite labels in HTML/SVG from verified terminology |
| `03-github-and-readme/readme-hero-banner-01.jpg` | README top visual | Verify crop and avoid duplicating the README title |
| `04-technical-architecture/system-architecture-illustration.jpg` | Decorative companion to exact architecture | Rebuild the actual diagram in Mermaid/SVG from source code |
| `04-technical-architecture/routing-lifecycle-illustration.jpg` | Routing lifecycle docs | Verify sequence and all stages against implementation |
| `04-technical-architecture/bounded-fallback-mechanism.jpg` | Fallback docs | Verify finite retry semantics and error paths against source |
| `05-documentation/*.jpg` | Documentation covers | Check title, scope, contrast, and consistency |
| `06-marketing/launch-announcement-concept.jpg` | Launch announcement draft | Remove/verify any launch, release, or production claims |
| `06-marketing/release-milestone-card.jpg` | Reusable release template | Replace example version and milestone text with verified release data |
| `07-social-media/*.jpg` | Social/banner drafts | Confirm dimensions and recompose text separately for platform-safe margins |
| `00-brand-system/chatgpt-generated-brand-board-concept.png` | Internal visual direction only | Do not crop as final assets or rely on its labels/features |

## Technical principle

**SabiRoute decides. LiteLLM executes. Evidence guides the path.**

SabiRoute controls routing policy; LiteLLM executes upstream requests. Do not treat generated architecture artwork as authoritative. No artwork is labelled approved or integrated in this package.
